package utilities;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.util.ArrayList;
import java.util.Random;
import java.util.regex.Pattern;
import application.Main;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;
import system.Handler;

public class Utilitie {
	private static double x, y;
	private static final int DURATION = 1;
	private static final double DURATION2 = DURATION / 2;
	public static final String EMAIL_REGEX = "^(([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
	public static final String PASSWORD_REGEX = "^(?=.*\\d).{8,16}$";
	public static final String TEL_REGEX = "^\\+[0-9]+(6|2)[0-9]+";

	public static void makeTransitionRandom(Parent p, Scene s) {
		p.setLayoutX(0);
		p.setLayoutY(0);
		Timeline timeline = new Timeline();
		KeyValue keyvalue;
		KeyFrame keyframe;

		if (generateNumber(1, 2) == 1) {
			p.translateYProperty().set(s.getHeight());
			keyvalue = new KeyValue(p.translateYProperty(), 0, Interpolator.EASE_IN);
		} else {
			p.translateXProperty().set(s.getWidth());
			keyvalue = new KeyValue(p.translateXProperty(), 0, Interpolator.EASE_IN);
		}

		// roots.get(i).rotateProperty().set(360);
		keyframe = new KeyFrame(Duration.seconds(DURATION), keyvalue);
		timeline.getKeyFrames().add(keyframe);

		timeline.play();
	}

	public static void translateAnimation(Node node, boolean left, double width) {
		TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(1), node);
		translateTransition.setByX(width);
		translateTransition.play();
	}

	public static void makeTransitionRandom(Parent p, Pane pane) {
		p.setLayoutX(0);
		p.setLayoutY(0);
		Timeline timeline = new Timeline();
		KeyValue keyvalue;
		KeyFrame keyframe;
		if (generateNumber(1, 2) == 1) {
			p.translateYProperty().set(pane.getHeight());
			keyvalue = new KeyValue(p.translateYProperty(), 0, Interpolator.EASE_IN);
		} else {
			p.translateXProperty().set(pane.getWidth());
			keyvalue = new KeyValue(p.translateXProperty(), 0, Interpolator.EASE_IN);
		}
		// p.rotateProperty().set(360);
		keyframe = new KeyFrame(Duration.seconds(DURATION), keyvalue);
		timeline.getKeyFrames().add(keyframe);

		timeline.play();
	}

	public static void makeTransition(Parent p, Pane pane, boolean left) {
		Timeline timeline = new Timeline();
		KeyValue keyvalue;
		KeyFrame keyframe;

		// p.setLayoutX(-pane.getWidth());
		if (left) {
			p.translateXProperty().set(-pane.getWidth());
			keyvalue = new KeyValue(p.translateXProperty(), 0, Interpolator.EASE_IN);
		} else {
			p.translateXProperty().set(pane.getWidth());
			keyvalue = new KeyValue(p.translateXProperty(), 0, Interpolator.EASE_IN);
		}
		// p.rotateProperty().set(360);
		keyframe = new KeyFrame(Duration.seconds(DURATION), keyvalue);

		timeline.getKeyFrames().add(keyframe);

		timeline.play();
	}

	public static int generateNumber(int min, int max) {
		return min + (int) (Math.random() * ((max - min) + 1));
	}

	public static void autoriseDeplacement(Parent p, Stage stage) {
		p.setOnMousePressed(event -> {
			x = event.getSceneX();
			y = event.getSceneY();
		});
		p.setOnMouseDragged(event -> {
			stage.setX(event.getScreenX() - x);
			stage.setY(event.getScreenY() - y);
			stage.setOpacity(0.7f);
		});
		p.setOnDragDone(event -> {
			stage.setOpacity(1.0f);
		});
		p.setOnMouseReleased(event -> {
			stage.setOpacity(1.0f);
		});
		/*
		 * roots.get(i).getStylesheets().removeAll();
		 * roots.get(i).getStylesheets().add(getClass().getResource("application.css").
		 * toExternalForm());
		 */
	}

	public static void closeApplication() {
		Main.handleServer.write(new Handler<>(Keywords.close, null));
		Main.handleServer.close();
		System.exit(0);
	}

	public static void sleep(int duration) {
		try {
			Thread.sleep(duration);
		} catch (InterruptedException e) {
			
		}
	}

	public static String generateIV() {
		String iv = "";
		Random rand = new Random();
		while (iv.length() < 16) {
			iv += (char) (rand.nextInt(26) + 'A');
		}
		System.out.println(iv);
		return iv;
	}

}