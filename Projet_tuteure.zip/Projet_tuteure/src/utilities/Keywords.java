package utilities;

public enum Keywords {
    error, 
    success, 
    addFile,
    getFile,
    image,
    close
}
