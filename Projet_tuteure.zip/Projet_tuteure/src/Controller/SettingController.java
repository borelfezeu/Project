package Controller;

import java.io.IOException;

import com.jfoenix.controls.JFXButton;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SettingController {

    @FXML
    private JFXButton back;

    @FXML
    private JFXButton save;

    @FXML
    void Accueil(ActionEvent event) throws IOException {
    	back.getScene().getWindow().hide();
		Stage stage= new Stage();
		Parent root= FXMLLoader.load(getClass().getResource("/View/Accueil.fxml"));
		Scene scene=new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Accueil Enseignant");
		stage.show();
    }

    @FXML
    void enregistrer(ActionEvent event) {

    }
}
