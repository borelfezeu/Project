package Controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import ConnectBD.BD;
import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class AccueilEnseignantController implements Initializable {

	@FXML
    private Label label;

    @FXML
    private Button consulhist;

    @FXML
    private Button fairedmd;

    @FXML
    private Button consulcmpt;

    @FXML
    private Button last;

    @FXML
    private Button annulerdmd;

    @FXML
    private Button exit;


	    @FXML
	    void annuler(ActionEvent event) {

	    }

	    @FXML
	    void consulter(ActionEvent event) {
	    	
	    }

	    @FXML
	    void consultercompte(ActionEvent event) throws Exception {
	    	try {
	    		Connection con= BD.connect();
	    		PreparedStatement ps=null;
	    		ResultSet res=null;
	    		String sql="SELECT * FROM utilisateur WHERE Nom = ? AND Id = ? ";	
	    		
	    		ps=con.prepareStatement(sql);
	    		ps.setString(1, Main.name.toString());
	    		ps.setString(2, Main.id.toString());
	    		res=ps.executeQuery();
	    		Boolean bool=res.next();
	    		
	    		if(bool)
	    		{
	    		Main.prenom=res.getString(2);
	    		Main.plafond=res.getInt(5);
	    		
	    		consulcmpt.getScene().getWindow().hide();
			    Stage stage = new Stage();
				Parent root = FXMLLoader.load(getClass().getResource("/View/ConsulterCompte.fxml"));
				Scene scene= new Scene(root);
				stage.setScene(scene);
				stage.setTitle("Etat du compte");
				stage.show();
	    		}
	    	}
	    	catch(SQLException e) {
	    		
	    	}
	    }

	    @FXML
	    void demander(ActionEvent event) throws IOException {
	    	try {
	    		fairedmd.getScene().getWindow().hide();
	    		Stage stage = new Stage();
				Parent root = FXMLLoader.load(getClass().getResource("/View/DemandePhotocopie.fxml"));
				Scene scene= new Scene(root);
				stage.setScene(scene);
				stage.setTitle("Demande de photocopies");
				stage.show();
	    	}
	    	catch(IOException e){
				e.printStackTrace();
	    	}
	    }

	    @FXML
	    void etatlastcmd(ActionEvent event) {

	    }

	    @FXML
	    void Accueil(ActionEvent event) {
			try {
				exit.getScene().getWindow().hide();
				Parent root = FXMLLoader.load(getClass().getResource("/View/Accueil.fxml"));
				Scene scene = new Scene(root);
				Stage stage=new Stage();
				stage.setScene(scene);
				stage.setTitle("Accueil Photocop's");
				stage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
	    }

		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			// TODO Auto-generated method stub
			
		}
}
