package Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import ConnectBD.BD;
import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import system.Handler;
import utilities.FilePicker;
import utilities.Keywords;
import javafx.stage.Stage;

public class DemandePhotocopieController implements Initializable  {

		 String author;
		 int nbex;
		 int nbpg;
		 String Format;
		 String Typedoc;
		 String color;
		 String recto;
		 File f;
		
		
	  @FXML
	    private Label label;

	    @FXML
	    private Button send;

	    @FXML
	    private TextField nbreex;

	    @FXML
	    private TextField nbrepage;

	    @FXML
	    private RadioButton nb;

	    @FXML
	    private RadioButton a3;

	    @FXML
	    private RadioButton a4;

	    @FXML
	    private RadioButton couleur;

	    @FXML
	    private RadioButton rec;

	    @FXML
	    private Button buttonimport;


	    @FXML
	    private RadioButton recver;

	    @FXML
	    private RadioButton td;

	    @FXML
	    private RadioButton examen;

	    @FXML
	    private RadioButton rapport;
	    
	    @FXML
	    private Button back;

	    @FXML
	    void A3(ActionEvent event) {
	    		Format="A3";
	    }

	    @FXML
	    void A4(ActionEvent event) {
    			Format="A4";
	    }

	    @FXML
	    void Color(ActionEvent event) {
	    		color="Oui";
	    }
	    
	    private ArrayList <String>lastfile= new ArrayList<String>();
	    

	    @FXML
	    void Retour(ActionEvent event) {
	    	try {
				back.getScene().getWindow().hide();
				Parent root = FXMLLoader.load(getClass().getResource("/View/AccueilEnseignant.fxml"));
				Scene scene = new Scene(root);
				Stage stage=new Stage();
				stage.setScene(scene);
				stage.setTitle("Accueil Enseignant");
				stage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void importer(MouseEvent event) {
	    	FilePicker filePicker = new FilePicker("S�lectionnez un fichier", "pdf","jpeg","png","jpg","txt");
	    	f = filePicker.chooseFile();
	    	/*FileChooser fc =new FileChooser();
	    	fc.getExtensionFilters().add(new ExtensionFilter("PDF", lastfile));
	    	File f=fc.showOpenDialog(null);*/
	    	
	    	String fileName = Main.name+f.getName().substring(f.getName().lastIndexOf("."));
			Main.nomfichier=fileName;
	    	FileInputStream in;
			try {
				in = new FileInputStream(f);
				byte b[] = new byte[in.available()];
                in.read(b);
                Main.handleServer.write(new Handler<byte[]>(Keywords.addFile, b,fileName));
                in.close();
			} catch (IOException e) {
				
			}
			
	    	if(f!=null) {
	    		buttonimport.setText("Fichier s�l�ctionn�"+f.getAbsolutePath());
	    	}
	    }
	    
	    @FXML
	    void Envoyer(ActionEvent event) throws Exception,SQLException {
		    
	
				try {
				Connection	conne = BD.connect();
				PreparedStatement ps=null;
				author=Main.name;

				String sql="INSERT INTO bondecommande VALUES(?,?,?,?,?,?,?,?,?)";
				ps =conne.prepareStatement(sql);
				ps.setString(1, author);
				ps.setInt(2, nbex);
				ps.setInt(3, nbpg);
				ps.setString(4, Format);
				ps.setString(5, Typedoc);
				ps.setString(6, color);
				ps.setString(7, recto);
				ps.setString(8, "Non");
				ps.setString(9, Main.nomfichier);

				
				ps.executeUpdate();
				
				/*String sql1="SELECT Id FROM bondecommande WHERE auteur=? AND nbreexemplaires= ? AND Format=? AND Typedoc=? ";
				PreparedStatement ps1=conne.prepareStatement(sql1);
				ps1.setString(1, author);
				ps1.setInt(2, nbex);
				ps1.setString(3, Format);
				ps1.setString(4, Typedoc);
				
				ResultSet rs=ps1.executeQuery();
				
					ID=rs.getInt(9);*/
				
				Alert dialog = new Alert(AlertType.INFORMATION);
				dialog.setTitle("REUSSITE");
				dialog.setHeaderText("Confirmation");
				dialog.setContentText("Votre commande a bien �t� enregistr�e.");
				dialog.showAndWait();
				
				
				
				}
					catch(SQLException e) {
				
				
					e.printStackTrace();
				}
				
				
			
	    }

	    @FXML
	    void Examen(ActionEvent event) {
	    	Typedoc="Examen";
	    }

	    @FXML
	    void NB(ActionEvent event) {
    		color="Non";
	    }

	    @FXML
	    void NbreExempl(ActionEvent event) {
	    		nbex=Integer.valueOf(nbreex.getText()); 
	    }

	    @FXML
	    void NbrePage(ActionEvent event) {
    		nbpg=Integer.valueOf(nbrepage.getText());

	    }

	    @FXML
	    void Rapport(ActionEvent event) {
	    	Typedoc="Rapport";
	    }

	    @FXML
	    void Recto(ActionEvent event) {
	    	recto="Recto";
	    }

	    @FXML
	    void Rectoverso(ActionEvent event) {
	    	recto="Recto & verso";

	    }

	    @FXML
	    void Td(ActionEvent event) {
	    	Typedoc="TD";
	    }

		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			lastfile.add("*.pdf");			
		}
		
}
