package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import ConnectBD.BD;
import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class loginController {
	
	@FXML private Button valider;
	
	  @FXML
	    private JFXTextField nom;

	    @FXML
	    private JFXPasswordField identifiant;

	    @FXML
	    private Button home;
	    
	@FXML private Label label;
	
	@FXML
	public void authentifier(ActionEvent event) throws SQLException{
		String name,id = null;
		name=nom.getText();
		id=identifiant.getText();
		try {
			Connection con=BD.connect();
		PreparedStatement ps=null;
		ResultSet res=null;
		String sql="SELECT * FROM utilisateur WHERE Nom = ? AND Id = ? AND Profil = \"admin\"";
		
			ps=con.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, id);
			res=ps.executeQuery();
			
			Boolean var=res.next();
			
		//String sql2="SELECT Profil FROM utilisateur WHERE Nom = \""+name+"\" AND Id = id ";
	
		String sql1="SELECT * FROM utilisateur WHERE Nom = ? AND Id = ? AND Profil = \"enseignant\"";
		PreparedStatement ps1=con.prepareStatement(sql1);
		ps1.setString(1, name);
		ps1.setString(2, id);
		ResultSet res1=ps1.executeQuery();
		Boolean var1=res1.next();
		
		String sql2="SELECT * FROM utilisateur WHERE Nom = ? AND Id = ? AND Profil = \"secretariat\"";
		PreparedStatement ps2=con.prepareStatement(sql2);
		ps2.setString(1, name);
		ps2.setString(2, id);
		ResultSet res2=ps2.executeQuery();
		Boolean var2=res2.next();
		
		
		
			if(var) {
				Main.name = name;
				Main.id= id;
				label.setText("Administrateur bien connect�.");
				valider.getScene().getWindow().hide();
				Stage stage= new Stage();
				Parent root= FXMLLoader.load(getClass().getResource("/View/AccueilAdmin.fxml"));
				Scene scene=new Scene(root);
				stage.setScene(scene);
				stage.setTitle("Accueil Administrateur");
				stage.show();
				
			}
				
			else if(var1)	{
				Main.name = name;
				Main.id= id;
				label.setText("Enseignant bien connect�.");
				valider.getScene().getWindow().hide();
				Stage stage= new Stage();
				Parent root= FXMLLoader.load(getClass().getResource("/View/AccueilEnseignant.fxml"));
				Scene scene=new Scene(root);
				stage.setScene(scene);
				stage.setTitle("Accueil Enseignant");
				stage.show();
					
			}
			else if(var2) {
				Main.name = name;
				Main.id= id;
				label.setText("Secretariat bien connect�.");
				valider.getScene().getWindow().hide();
				Stage stage= new Stage();
				Parent root= FXMLLoader.load(getClass().getResource("/View/AccueilSecretariat.fxml"));
				Scene scene=new Scene(root);
				stage.setScene(scene);
				stage.setTitle("Accueil Secretariat");
				stage.show();
			}
			
			else {
				label.setText("Utilisateur introuvable. Veuillez r�essayez.");
				Alert dialog = new Alert(AlertType.ERROR);
				dialog.setTitle("Erreur");
				dialog.setHeaderText("Erreur Authentification");
				dialog.setContentText("Veuillez entrer des champs corrects");
				dialog.showAndWait();
				
			
				
			}

	}
		catch(Exception e) {	}
	}
	
	@FXML
    void Accueil(ActionEvent event) {
		try {
			home.getScene().getWindow().hide();
			Parent root = FXMLLoader.load(getClass().getResource("/View/Accueil.fxml"));
			Scene scene = new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.setTitle("Accueil Photocop's");
			stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
    }
	
}

