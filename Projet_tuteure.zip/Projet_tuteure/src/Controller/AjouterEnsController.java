package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import ConnectBD.BD;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class AjouterEnsController {
	 @FXML
	    private Label label;

	    @FXML
	    private TextField nomens;

	    @FXML
	    private TextField prenomens;

	    @FXML
	    private TextField idens;

	    @FXML
	    private TextField plafens;

	    @FXML
	    private Button back;

	    @FXML
	    private Button send;

	    @FXML
	    void envoyer(ActionEvent event) throws SQLException {
	    	String n,pre,pro,identify;
	    	int pl;
	    	
	    	n=nomens.getText();
	    	pre=prenomens.getText();
	    	identify=idens.getText();
	    	pro="enseignant";
	    	pl=Integer.valueOf(plafens.getText());
	    	try {
				Connection c=BD.connect();
				PreparedStatement ps=null;
				
				String sql="INSERT INTO utilisateur VALUES(?,?,?,?,?)";
				ps=c.prepareStatement(sql);
				ps.setString(1, n);
				ps.setString(2, pre);
				ps.setString(3, identify);
				ps.setString(4, pro);
				ps.setInt(5, pl);
				
				ps.executeUpdate();
				
				Alert dialog = new Alert(AlertType.INFORMATION);
				dialog.setTitle("REUSSITE");
				dialog.setHeaderText("Confirmation");
				dialog.setContentText("L'enregistrement a bien �t� enregistr�e");
				dialog.showAndWait();
				
				nomens.setText(null);
				prenomens.setText(null);
				idens.setText(null);
				plafens.setText(null);


			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    }

	    @FXML
	    void rentrer(ActionEvent event) {
	    	try {
				back.getScene().getWindow().hide();
				Parent root = FXMLLoader.load(getClass().getResource("/View/AccueilEnseignant.fxml"));
				Scene scene = new Scene(root);
				Stage stage=new Stage();
				stage.setScene(scene);
				stage.setTitle("Accueil Enseignant");
				stage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
	    }
}
