package Controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class AccueilController {

	@FXML private Button apropos;
	@FXML private Button seconnecter;
    @FXML
    private Button setting;
    
    @FXML
    void parametre(ActionEvent event) {
    	try {
    		setting.getScene().getWindow().hide();
    		Stage stage= new Stage();
    		Parent root= FXMLLoader.load(getClass().getResource("/View/Setting.fxml"));
    		Scene scene=new Scene(root);
    		stage.setScene(scene);
    		stage.setTitle("Page des param�tres");
    		stage.show();
    		}
    		catch(Exception e) {
    			
    		}
    }
	
	 @FXML
	    void pageconnection(ActionEvent event) throws IOException{
		try {
		seconnecter.getScene().getWindow().hide();
		Stage stage= new Stage();
		Parent root= FXMLLoader.load(getClass().getResource("/View/Authentification.fxml"));
		Scene scene=new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Page d'authentification");
		stage.show();
		}
		catch(Exception e) {
			
		}
	}
	 
	  @FXML
	    void about(ActionEvent event) {
		  try {
				apropos.getScene().getWindow().hide();
				Parent root = FXMLLoader.load(getClass().getResource("/View/Avant-Propos.fxml"));
				Scene scene = new Scene(root);
				Stage stage=new Stage();
				stage.setScene(scene);
				stage.setTitle("Avant-Propos");
				stage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
			

	    }

	
}
