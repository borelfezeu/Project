package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import ConnectBD.BD;
import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class GereDemandeController {
	
    @FXML
    private TextField nomens;

    @FXML
    private TextField nomfich;

    @FXML
    private Button exit;

    @FXML
    private Button send;

    @FXML
    void Accueil(ActionEvent event) throws Exception {

		
    	try {
			exit.getScene().getWindow().hide();
			Parent root = FXMLLoader.load(getClass().getResource("/View/Accueil.fxml"));
			Scene scene = new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.setTitle("Accueil Photocop's");
			stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		
    }

    @FXML
    void envoyer(ActionEvent event) throws Exception {
    	try {
    		Connection	conne = BD.connect();
    		PreparedStatement ps=null;

    		String sql="UPDATE bondecommande set Valid�='Oui' WHERE auteur=\""+nomens.getText()+"\" AND Nomdufichier=\""+nomfich.getText();
    		ps =conne.prepareStatement(sql);
    		ps.executeUpdate();
    		
    		
    		
    		Alert dialog = new Alert(AlertType.INFORMATION);
    		dialog.setTitle("REUSSITE");
    		dialog.setHeaderText("Confirmation");
    		dialog.setContentText("Votre commande a bien �t� valid� et ira au traitement.");
    		dialog.showAndWait();
    		
    		
    		
    		}
    			catch(SQLException e) {
    		
    		
    			e.printStackTrace();
    		}
    }

}
