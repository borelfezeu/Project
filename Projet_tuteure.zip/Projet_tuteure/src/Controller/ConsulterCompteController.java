package Controller;

import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ConsulterCompteController implements Initializable{
	
	 @FXML
	    private Button exit;

	    @FXML
	    private Label prenom;

	    @FXML
	    private Label nom;

	    @FXML
	    private Label plafond;

	    @FXML
	    private Label message;

	    @FXML
	    private Button back;

	    @FXML
	    void Accueil(ActionEvent event) {
	    	
	    	try {
				exit.getScene().getWindow().hide();
				Parent root = FXMLLoader.load(getClass().getResource("/View/Accueil.fxml"));
				Scene scene = new Scene(root);
				Stage stage=new Stage();
				stage.setScene(scene);
				stage.setTitle("Accueil Photocop's");
				stage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
	    }

	    @FXML
	    void rentrer(ActionEvent event) {
	    	try {
				back.getScene().getWindow().hide();
				Parent root = FXMLLoader.load(getClass().getResource("/View/AccueilEnseignant.fxml"));
				Scene scene = new Scene(root);
				Stage stage=new Stage();
				stage.setScene(scene);
				stage.setTitle("Accueil Enseignant");
				stage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
	    }

		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			
			nom.setText(Main.name);
			prenom.setText(Main.prenom);
			plafond.setText(String.valueOf(Main.plafond));
			
			message.setText("Il vous reste "+String.valueOf(Main.plafond)+" photocopies.");
		}

}
