package Controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class AccueilAdminController {
	
	 @FXML
	    private Label label;

	    @FXML
	    private Button addens;

	    @FXML
	    private Button suppens;

	    @FXML
	    private Button exit;

	    @FXML
	    private Button last;

	    @FXML
	    private Button historique;


    @FXML
    void ajoutenseignant(ActionEvent event) throws IOException {
    	addens.getScene().getWindow().hide();
		 Stage stage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("/View/AjouterEns.fxml"));
			Scene scene= new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Ajout Enseignant");
			stage.show();
    	
    }


    @FXML
    void etatlastcmd(ActionEvent event) {
    	try {
			last.getScene().getWindow().hide();
			Parent root = FXMLLoader.load(getClass().getResource("/View/GereDemande.fxml"));
			Scene scene = new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.setTitle("Gerer demande");
			stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}

    }

    @FXML
    void accueil(ActionEvent event) {
		try {
			exit.getScene().getWindow().hide();
			Parent root = FXMLLoader.load(getClass().getResource("/View/Accueil.fxml"));
			Scene scene = new Scene(root);
			Stage stage=new Stage();
			stage.setScene(scene);
			stage.setTitle("Accueil Photocop's");
			stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
    }

    
    
    @FXML
    void supprimerenseignant(ActionEvent event) {

    }
    
    @FXML
    void afficherhistorique(ActionEvent event) {

    }

  
}
