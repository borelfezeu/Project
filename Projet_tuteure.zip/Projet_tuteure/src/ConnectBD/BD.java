package ConnectBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class BD {
	public BD(String host,int port,String dbName,String username,String password) {
		this.url="jdbc:mysql://"+host+":"+port+"/"+dbName;
		this.username=username;
		this.password=password;
	}

	public static String nameDriver="com.mysql.jdbc.Driver";
	public String url="";
	public String username="";
	public String password="";
	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public static void charger() throws Exception // charger le driver
	{
		try 
		{
			Class.forName(nameDriver);
			 System.out.println("Driver charg� avec succ�s.");

		}
		catch(Exception exc) 
		{
			 System.err.println("ERROR : Driver non charg� .");
		}	
	}
	
	
	public static Connection connect() throws Exception
	{
		Connection conn=null;

		try {
			BD.charger();
		BD obj=new BD("127.0.0.1",3306,"bd_projet_tuteure","root","");
		conn=(Connection) DriverManager.getConnection(obj.getUrl(),obj.getUsername(),obj.getPassword());
		 System.out.println("Connexion �tablie avec succ�s.");
		}
		catch(SQLException e) {
			 System.out.println("ERROR : "+e.getMessage());

		}
		return conn;
	}
	
	PreparedStatement stat=null;
	ResultSet rs=null;
	
	public  void fermer() throws SQLException {
		if(rs!=null)
		{
			rs.close();
		}
	}
	
	
}
