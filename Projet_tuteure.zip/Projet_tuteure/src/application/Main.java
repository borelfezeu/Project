package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import system.Client;
import system.HandleServer;
import javafx.scene.Parent;
import javafx.scene.Scene;


public class Main extends Application {
	public static HandleServer handleServer = null;
	public static String name,id = null;
	
	public static String prenom;//consulter compte
	public static int plafond;//consulter compte
	public static String nomfichier;


	@Override
	public void start(Stage primaryStage) {
		handleServer = new Client("127.0.0.1",3000).launch();
		if(handleServer == null) System.exit(1);
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/View/Accueil.fxml"));
			Scene scene = new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.setTitle("Accueil Photocop's");
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
