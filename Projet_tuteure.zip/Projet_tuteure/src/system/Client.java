package system;

import java.io.IOException;
import java.net.Socket;

public class Client {
	private Socket clientSocket;
	private String inetAddress;
	private int port;

	public Client(String inetAddress, int port) {
		this.inetAddress = inetAddress;
		this.port = port;
	}

	public HandleServer launch() {
		System.out.println("Lancement du client");
		try {
			clientSocket = new Socket(inetAddress,port);
			HandleServer handleServer = new HandleServer(clientSocket);
			Thread t = new Thread(handleServer);
			t.start();
			return handleServer;
		} catch (IOException e) {
			
		}
		return null;
	}
}
