package Modele;

public class Enseignant {
	String Nom;
	String Prenom;
	int Plafond;
	int Id;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}
	
	public String getNom() {
		return Nom;
	}

	public void setNom(String nom) {
		Nom = nom;
	}

	public String getPrenom() {
		return Prenom;
	}

	public void setPrenom(String prenom) {
		Prenom = prenom;
	}

	public int getPlafond() {
		return Plafond;
	}

	public void setPlafond(int plafond) {
		Plafond = plafond;
	}

	public void faire_demande() {
		
	}
	
	public void consulter_compte() {
		
	}
}
