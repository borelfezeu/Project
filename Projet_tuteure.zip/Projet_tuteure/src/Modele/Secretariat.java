package Modele;

public class Secretariat {
	String Identifiant;
	String login;
}
