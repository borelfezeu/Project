package Modele;

public class BonDeCommande {
	String AuteurDemande;
	int NbreExemplaires;
	
}
