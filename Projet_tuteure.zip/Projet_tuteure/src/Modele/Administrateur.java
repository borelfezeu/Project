package Modele;

import java.util.Scanner;

public class Administrateur {
	String Id;
	int Login;
	
	
	
}
